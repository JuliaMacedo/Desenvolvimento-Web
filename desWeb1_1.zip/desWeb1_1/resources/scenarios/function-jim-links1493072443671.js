(function(window, undefined) {

  var jimLinks = {
    "712267c5-e2ac-43bf-af8e-cbc4089e9775" : {
      "Label_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_6" : [
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d",
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d"
      ],
      "Label_4" : [
        "712267c5-e2ac-43bf-af8e-cbc4089e9775",
        "712267c5-e2ac-43bf-af8e-cbc4089e9775"
      ],
      "Label_7" : [
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c",
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c"
      ],
      "Label_8" : [
        "8b55c4c6-31c6-449c-91c9-186657af5c15",
        "8b55c4c6-31c6-449c-91c9-186657af5c15"
      ],
      "Label_9" : [
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460"
      ]
    },
    "8b55c4c6-31c6-449c-91c9-186657af5c15" : {
      "Label_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_8" : [
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d"
      ],
      "Label_6" : [
        "712267c5-e2ac-43bf-af8e-cbc4089e9775"
      ],
      "Label_7" : [
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c",
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c"
      ],
      "Label_4" : [
        "8b55c4c6-31c6-449c-91c9-186657af5c15"
      ],
      "Label_9" : [
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460"
      ]
    },
    "5c33fb7e-0e4a-4881-a117-a5c57f21f38c" : {
      "Label_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_7" : [
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d",
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d"
      ],
      "Label_6" : [
        "712267c5-e2ac-43bf-af8e-cbc4089e9775",
        "712267c5-e2ac-43bf-af8e-cbc4089e9775"
      ],
      "Label_4" : [
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c",
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c"
      ],
      "Label_8" : [
        "8b55c4c6-31c6-449c-91c9-186657af5c15",
        "8b55c4c6-31c6-449c-91c9-186657af5c15"
      ],
      "Label_9" : [
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460"
      ]
    },
    "40a1be66-3cf4-4cfd-afef-6b26bd3f973d" : {
      "Label_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_4" : [
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d",
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d"
      ],
      "Label_6" : [
        "712267c5-e2ac-43bf-af8e-cbc4089e9775",
        "712267c5-e2ac-43bf-af8e-cbc4089e9775"
      ],
      "Label_7" : [
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c"
      ],
      "Label_8" : [
        "8b55c4c6-31c6-449c-91c9-186657af5c15"
      ],
      "Label_9" : [
        "c88e6d3b-782c-4738-954f-cbd13171f460"
      ]
    },
    "c88e6d3b-782c-4738-954f-cbd13171f460" : {
      "Label_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_8" : [
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d"
      ],
      "Label_6" : [
        "712267c5-e2ac-43bf-af8e-cbc4089e9775"
      ],
      "Label_7" : [
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c"
      ],
      "Label_9" : [
        "8b55c4c6-31c6-449c-91c9-186657af5c15",
        "8b55c4c6-31c6-449c-91c9-186657af5c15"
      ],
      "Label_4" : [
        "c88e6d3b-782c-4738-954f-cbd13171f460"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Label_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_5" : [
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d",
        "40a1be66-3cf4-4cfd-afef-6b26bd3f973d"
      ],
      "Label_6" : [
        "712267c5-e2ac-43bf-af8e-cbc4089e9775",
        "712267c5-e2ac-43bf-af8e-cbc4089e9775"
      ],
      "Label_7" : [
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c",
        "5c33fb7e-0e4a-4881-a117-a5c57f21f38c"
      ],
      "Label_8" : [
        "8b55c4c6-31c6-449c-91c9-186657af5c15",
        "8b55c4c6-31c6-449c-91c9-186657af5c15"
      ],
      "Label_9" : [
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460",
        "c88e6d3b-782c-4738-954f-cbd13171f460"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);